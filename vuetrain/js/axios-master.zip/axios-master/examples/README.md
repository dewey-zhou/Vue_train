# axios examples

To run the examples:

1. `git clone https://github.com/axios/axios.git`
2. `cd axios`
3. `npm install`
4. `grunt build`
5. `npm run examples`
6. [http://localhost:3000](http://localhost:3000)

Or use Gitpod, a free dev environment for GitHub:

[![Open in Gitpod](https://gitpod.io/button/open-in-gitpod.svg)](https://gitpod.io/#https://github.com/axios/axios/blob/master/examples/server.js)
